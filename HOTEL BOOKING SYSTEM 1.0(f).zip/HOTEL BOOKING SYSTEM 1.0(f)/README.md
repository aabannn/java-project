# 🏨 Hotel Booking System — Java Application

**Course:** Java | **College:** MEA  
**Team:** Shahin · Aban · Ajmal · Shamnoon

---

## Project Structure

```
HotelBookingSystem/
├── src/hotel/
│   ├── Main.java                    ← Entry point
│   ├── config/
│   │   ├── DatabaseConfig.java      ← DB credentials & URL
│   │   └── DatabaseConnection.java ← Singleton JDBC connection
│   ├── model/
│   │   ├── Customer.java
│   │   ├── Room.java
│   │   ├── Booking.java
│   │   └── Payment.java
│   ├── dao/
│   │   ├── CustomerDAO.java
│   │   ├── RoomDAO.java
│   │   ├── BookingDAO.java
│   │   └── PaymentDAO.java
│   ├── service/
│   │   ├── AuthService.java
│   │   ├── BookingService.java
│   │   └── RoomService.java
│   ├── ui/
│   │   ├── LoginPanel.java
│   │   ├── RegisterPanel.java
│   │   ├── AdminDashboard.java
│   │   └── CustomerDashboard.java
│   └── util/
│       ├── PasswordUtil.java
│       ├── ValidationUtil.java
│       └── UITheme.java
├── sql/
│   └── hotel_schema.sql             ← Run this FIRST in MySQL
├── lib/
│   └── mysql-connector-j-*.jar      ← Place MySQL JDBC driver here
├── build.sh                         ← Linux/macOS build & run
├── build.bat                        ← Windows build & run
└── README.md
```

---

## Setup Instructions

### Step 1 — Install Prerequisites
- Java JDK 8 or higher  
- MySQL Server 5.7+  
- MySQL Connector/J (JDBC driver)

### Step 2 — Download MySQL Connector/J
1. Visit: https://dev.mysql.com/downloads/connector/j/
2. Download the Platform Independent ZIP
3. Extract and copy `mysql-connector-j-X.X.X.jar` into the `lib/` folder

### Step 3 — Create the Database
```bash
mysql -u root -p < sql/hotel_schema.sql
```

### Step 4 — Configure Database Credentials
Open `src/hotel/config/DatabaseConfig.java` and update:
```java
public static final String USERNAME = "root";      // your MySQL user
public static final String PASSWORD = "yourpass";  // your MySQL password
```

### Step 5 — Create the Admin Account
Since password hashing uses a salt, run this small snippet to generate the correct hash, then update the database:
```java
// Temporary: run once, paste the hash into MySQL
System.out.println(hotel.util.PasswordUtil.hash("admin123"));
```
Then in MySQL:
```sql
USE hotel_booking_db;
UPDATE customers SET password = '<paste hash here>' WHERE username = 'admin';
```

> **Tip:** Alternatively, register via the UI and manually update the role to `ADMIN` in MySQL.

### Step 6 — Build and Run

**Linux / macOS:**
```bash
chmod +x build.sh
./build.sh
```

**Windows:**
```
build.bat
```

---

## Default Credentials (after Step 5)

| Role  | Username | Password  |
|-------|----------|-----------|
| Admin | admin    | admin123  |

---

## Features

### Admin Panel
- 📊 Live dashboard (rooms, bookings, revenue)
- 🛏 Room management (add / delete / update)
- 📋 View and cancel any booking
- 👥 Customer directory
- 💳 Full payment history

### Customer Portal
- 🔍 Search available rooms by date
- 📅 Book a room with payment method selection
- 📋 View and cancel personal bookings

### Security
- SHA-256 + salt password hashing
- Role-based access control (Admin / Customer)
- SQL injection prevention via PreparedStatement
- Input validation on all forms

---

## Architecture

```
UI Layer (Swing)
     ↕
Service Layer (Business Logic)
     ↕
DAO Layer (JDBC / MySQL)
     ↕
MySQL Database
```

---

## Technologies
| Technology | Purpose |
|------------|---------|
| Java 8+    | Core language |
| Swing      | GUI framework |
| MySQL      | Database |
| JDBC       | DB connectivity |
| SHA-256    | Password hashing |

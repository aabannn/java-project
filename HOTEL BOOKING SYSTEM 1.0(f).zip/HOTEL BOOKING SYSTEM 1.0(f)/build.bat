@echo off
:: ============================================================
::  build.bat  –  Compile and run Hotel Booking System (Windows)
:: ============================================================

setlocal

set PROJECT_ROOT=%~dp0
set SRC_DIR=%PROJECT_ROOT%src
set OUT_DIR=%PROJECT_ROOT%out
set LIB_DIR=%PROJECT_ROOT%lib
set MAIN_CLASS=hotel.Main

:: Find MySQL connector JAR
set MYSQL_JAR=
for %%f in ("%LIB_DIR%\mysql-connector*.jar") do set MYSQL_JAR=%%f

if "%MYSQL_JAR%"=="" (
    echo [ERROR] MySQL Connector/J not found in lib\
    echo Download from https://dev.mysql.com/downloads/connector/j/
    pause
    exit /b 1
)

:: Compile
echo [INFO] Compiling...
if not exist "%OUT_DIR%" mkdir "%OUT_DIR%"
dir /s /b "%SRC_DIR%\*.java" > %TEMP%\sources.txt
javac -d "%OUT_DIR%" -cp "%MYSQL_JAR%" @%TEMP%\sources.txt
if %ERRORLEVEL% neq 0 ( echo [ERROR] Compilation failed. & pause & exit /b 1 )
echo [INFO] Compilation successful.

:: Run
echo [INFO] Launching application...
java -cp "%OUT_DIR%;%MYSQL_JAR%" %MAIN_CLASS%

endlocal
pause

#!/usr/bin/env bash
# ============================================================
#  build.sh  –  Compile and run the Hotel Booking System
#
#  Prerequisites
#  ─────────────
#  1. Java JDK 8+  (java & javac on your PATH)
#  2. MySQL Connector/J JAR placed in  lib/mysql-connector-j-*.jar
#     Download: https://dev.mysql.com/downloads/connector/j/
#  3. MySQL server running; schema created:
#        mysql -u root -p < sql/hotel_schema.sql
#
#  Usage
#  ─────
#  chmod +x build.sh
#  ./build.sh          # compile + run
#  ./build.sh compile  # compile only
#  ./build.sh run      # run only (after compile)
# ============================================================

set -e

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC_DIR="$PROJECT_ROOT/src"
OUT_DIR="$PROJECT_ROOT/out"
LIB_DIR="$PROJECT_ROOT/lib"
MAIN_CLASS="hotel.Main"

# ── Locate MySQL connector ───────────────────────────────────
MYSQL_JAR=$(find "$LIB_DIR" -name "mysql-connector*.jar" 2>/dev/null | head -1)
if [[ -z "$MYSQL_JAR" ]]; then
    echo "❌  MySQL Connector/J not found in lib/"
    echo "    Download from https://dev.mysql.com/downloads/connector/j/"
    echo "    and place the JAR in the lib/ folder."
    exit 1
fi

CLASSPATH="$OUT_DIR:$MYSQL_JAR"

compile() {
    echo "🔧  Compiling sources..."
    mkdir -p "$OUT_DIR"
    find "$SRC_DIR" -name "*.java" > /tmp/sources.txt
    javac -d "$OUT_DIR" -cp "$MYSQL_JAR" @/tmp/sources.txt
    echo "✅  Compilation successful."
}

run() {
    echo "🚀  Starting Hotel Booking System..."
    java -cp "$CLASSPATH" "$MAIN_CLASS"
}

case "${1:-all}" in
    compile) compile ;;
    run)     run     ;;
    *)       compile && run ;;
esac

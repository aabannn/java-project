package hotel.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * Represents a room booking / reservation.
 */
public class Booking {

    public enum Status { PENDING, CONFIRMED, CANCELLED, COMPLETED }

    private int           bookingId;
    private int           customerId;
    private int           roomId;
    private LocalDate     checkInDate;
    private LocalDate     checkOutDate;
    private double        totalAmount;
    private Status        status;
    private LocalDateTime createdAt;
    private String        specialRequests;

    // Joined fields (not stored in bookings table)
    private String customerName;
    private String roomNumber;
    private String roomType;

    // ── Constructors ─────────────────────────────────────────────────────────

    public Booking() {}

    public Booking(int customerId, int roomId,
                   LocalDate checkIn, LocalDate checkOut,
                   double totalAmount, String specialRequests) {
        this.customerId      = customerId;
        this.roomId          = roomId;
        this.checkInDate     = checkIn;
        this.checkOutDate    = checkOut;
        this.totalAmount     = totalAmount;
        this.specialRequests = specialRequests;
        this.status          = Status.CONFIRMED;
    }

    // ── Business Logic ───────────────────────────────────────────────────────

    public long getNights() {
        if (checkInDate == null || checkOutDate == null) return 0;
        return ChronoUnit.DAYS.between(checkInDate, checkOutDate);
    }

    // ── Getters & Setters ────────────────────────────────────────────────────

    public int           getBookingId()    { return bookingId; }
    public void          setBookingId(int id) { this.bookingId = id; }

    public int           getCustomerId()   { return customerId; }
    public void          setCustomerId(int id) { this.customerId = id; }

    public int           getRoomId()       { return roomId; }
    public void          setRoomId(int id) { this.roomId = id; }

    public LocalDate     getCheckInDate()  { return checkInDate; }
    public void          setCheckInDate(LocalDate d) { this.checkInDate = d; }

    public LocalDate     getCheckOutDate() { return checkOutDate; }
    public void          setCheckOutDate(LocalDate d) { this.checkOutDate = d; }

    public double        getTotalAmount()  { return totalAmount; }
    public void          setTotalAmount(double a) { this.totalAmount = a; }

    public Status        getStatus()       { return status; }
    public void          setStatus(Status s) { this.status = s; }

    public LocalDateTime getCreatedAt()    { return createdAt; }
    public void          setCreatedAt(LocalDateTime dt) { this.createdAt = dt; }

    public String        getSpecialRequests() { return specialRequests; }
    public void          setSpecialRequests(String r) { this.specialRequests = r; }

    public String        getCustomerName() { return customerName; }
    public void          setCustomerName(String n) { this.customerName = n; }

    public String        getRoomNumber()   { return roomNumber; }
    public void          setRoomNumber(String n) { this.roomNumber = n; }

    public String        getRoomType()     { return roomType; }
    public void          setRoomType(String t) { this.roomType = t; }

    @Override
    public String toString() {
        return "Booking{id=" + bookingId + ", customerId=" + customerId
                + ", roomId=" + roomId + ", checkIn=" + checkInDate
                + ", checkOut=" + checkOutDate + ", amount=" + totalAmount
                + ", status=" + status + "}";
    }
}

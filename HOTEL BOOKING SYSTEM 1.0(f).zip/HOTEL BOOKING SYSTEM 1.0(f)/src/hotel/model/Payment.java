package hotel.model;

import java.time.LocalDateTime;

/**
 * Represents a payment transaction.
 */
public class Payment {

    public enum Status { PENDING, COMPLETED, REFUNDED, FAILED }
    public enum Method { CASH, CARD, ONLINE }

    private int           paymentId;
    private int           bookingId;
    private double        amount;
    private double        taxAmount;
    private double        totalAmount;
    private Method        paymentMethod;
    private Status        paymentStatus;
    private LocalDateTime paymentDate;
    private String        transactionRef;

    // Joined field
    private String customerName;

    // ── Constructors ─────────────────────────────────────────────────────────

    public Payment() {}

    public Payment(int bookingId, double amount, Method method) {
        this.bookingId     = bookingId;
        this.amount        = amount;
        this.taxAmount     = amount * 0.10;          // 10 % tax
        this.totalAmount   = amount + this.taxAmount;
        this.paymentMethod = method;
        this.paymentStatus = Status.COMPLETED;
        this.paymentDate   = LocalDateTime.now();
        this.transactionRef = "TXN-" + System.currentTimeMillis();
    }

    // ── Getters & Setters ────────────────────────────────────────────────────

    public int           getPaymentId()     { return paymentId; }
    public void          setPaymentId(int id) { this.paymentId = id; }

    public int           getBookingId()     { return bookingId; }
    public void          setBookingId(int id) { this.bookingId = id; }

    public double        getAmount()        { return amount; }
    public void          setAmount(double a) { this.amount = a; }

    public double        getTaxAmount()     { return taxAmount; }
    public void          setTaxAmount(double t) { this.taxAmount = t; }

    public double        getTotalAmount()   { return totalAmount; }
    public void          setTotalAmount(double t) { this.totalAmount = t; }

    public Method        getPaymentMethod() { return paymentMethod; }
    public void          setPaymentMethod(Method m) { this.paymentMethod = m; }

    public Status        getPaymentStatus() { return paymentStatus; }
    public void          setPaymentStatus(Status s) { this.paymentStatus = s; }

    public LocalDateTime getPaymentDate()   { return paymentDate; }
    public void          setPaymentDate(LocalDateTime d) { this.paymentDate = d; }

    public String        getTransactionRef() { return transactionRef; }
    public void          setTransactionRef(String r) { this.transactionRef = r; }

    public String        getCustomerName()  { return customerName; }
    public void          setCustomerName(String n) { this.customerName = n; }

    @Override
    public String toString() {
        return "Payment{id=" + paymentId + ", bookingId=" + bookingId
                + ", total=" + totalAmount + ", method=" + paymentMethod
                + ", status=" + paymentStatus + "}";
    }
}

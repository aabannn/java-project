package hotel.model;

import java.time.LocalDateTime;

/**
 * Represents a hotel customer / guest account.
 */
public class Customer {

    private int    customerId;
    private String name;
    private String email;
    private String phone;
    private String address;
    private String username;
    private String password;          // stored as BCrypt hash
    private String role;              // "ADMIN" | "CUSTOMER"
    private boolean active;
    private LocalDateTime createdAt;

    // ── Constructors ────────────────────────────────────────────────────────

    public Customer() {}

    public Customer(String name, String email, String phone,
                    String address, String username, String password, String role) {
        this.name     = name;
        this.email    = email;
        this.phone    = phone;
        this.address  = address;
        this.username = username;
        this.password = password;
        this.role     = role;
        this.active   = true;
    }

    // ── Getters & Setters ────────────────────────────────────────────────────

    public int    getCustomerId()  { return customerId; }
    public void   setCustomerId(int customerId) { this.customerId = customerId; }

    public String getName()        { return name; }
    public void   setName(String name) { this.name = name; }

    public String getEmail()       { return email; }
    public void   setEmail(String email) { this.email = email; }

    public String getPhone()       { return phone; }
    public void   setPhone(String phone) { this.phone = phone; }

    public String getAddress()     { return address; }
    public void   setAddress(String address) { this.address = address; }

    public String getUsername()    { return username; }
    public void   setUsername(String username) { this.username = username; }

    public String getPassword()    { return password; }
    public void   setPassword(String password) { this.password = password; }

    public String getRole()        { return role; }
    public void   setRole(String role) { this.role = role; }

    public boolean isActive()      { return active; }
    public void    setActive(boolean active) { this.active = active; }

    public LocalDateTime getCreatedAt()  { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public boolean isAdmin()       { return "ADMIN".equalsIgnoreCase(role); }

    @Override
    public String toString() {
        return "Customer{id=" + customerId + ", name='" + name
                + "', email='" + email + "', role='" + role + "'}";
    }
}

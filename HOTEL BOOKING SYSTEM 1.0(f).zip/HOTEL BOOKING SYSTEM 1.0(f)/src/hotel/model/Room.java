package hotel.model;

/**
 * Represents a hotel room.
 */
public class Room {

    public enum Status { AVAILABLE, BOOKED, MAINTENANCE }
    public enum RoomType { SINGLE, DOUBLE, SUITE, DELUXE, PENTHOUSE }

    private int      roomId;
    private String   roomNumber;
    private RoomType roomType;
    private double   pricePerNight;
    private Status   status;
    private String   amenities;
    private int      capacity;
    private String   description;

    // ── Constructors ─────────────────────────────────────────────────────────

    public Room() {}

    public Room(String roomNumber, RoomType roomType,
                double pricePerNight, int capacity, String amenities, String description) {
        this.roomNumber    = roomNumber;
        this.roomType      = roomType;
        this.pricePerNight = pricePerNight;
        this.capacity      = capacity;
        this.amenities     = amenities;
        this.description   = description;
        this.status        = Status.AVAILABLE;
    }

    // ── Getters & Setters ────────────────────────────────────────────────────

    public int      getRoomId()         { return roomId; }
    public void     setRoomId(int id)   { this.roomId = id; }

    public String   getRoomNumber()     { return roomNumber; }
    public void     setRoomNumber(String n) { this.roomNumber = n; }

    public RoomType getRoomType()       { return roomType; }
    public void     setRoomType(RoomType t) { this.roomType = t; }

    public double   getPricePerNight()  { return pricePerNight; }
    public void     setPricePerNight(double p) { this.pricePerNight = p; }

    public Status   getStatus()         { return status; }
    public void     setStatus(Status s) { this.status = s; }

    public String   getAmenities()      { return amenities; }
    public void     setAmenities(String a) { this.amenities = a; }

    public int      getCapacity()       { return capacity; }
    public void     setCapacity(int c)  { this.capacity = c; }

    public String   getDescription()    { return description; }
    public void     setDescription(String d) { this.description = d; }

    public boolean  isAvailable()       { return status == Status.AVAILABLE; }

    @Override
    public String toString() {
        return "Room{id=" + roomId + ", number='" + roomNumber
                + "', type=" + roomType + ", price=" + pricePerNight
                + ", status=" + status + "}";
    }
}

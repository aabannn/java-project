package hotel.config;

/**
 * Database Configuration Constants
 * Modify these values to match your MySQL setup.
 */
public class DatabaseConfig {
    public static final String HOST     = "localhost";
    public static final int    PORT     = 3306;
    public static final String DB_NAME  = "mydb";
    public static final String USERNAME = "aban";
    public static final String PASSWORD = "pass12";   // change as needed

    public static final String URL =
            "jdbc:mysql://" + HOST + ":" + PORT + "/" + DB_NAME
            + "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";

    // Connection pool settings
    public static final int MAX_POOL_SIZE = 10;
    public static final int CONNECTION_TIMEOUT = 30000;

    private DatabaseConfig() {}   // utility class – no instances
}

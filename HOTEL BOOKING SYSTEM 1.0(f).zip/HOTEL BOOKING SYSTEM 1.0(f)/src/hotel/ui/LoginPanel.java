package hotel.ui;

import hotel.model.Customer;
import hotel.service.AuthService;
import hotel.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 * Login screen – first window the user sees.
 */
public class LoginPanel extends JFrame {

    private final AuthService authService = new AuthService();

    private JTextField     usernameField;
    private JPasswordField passwordField;
    private JLabel         statusLabel;

    public LoginPanel() {
        setTitle("🏨  Hotel Booking System – Login");
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setSize(460, 520);
        setLocationRelativeTo(null);
        setResizable(false);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.BG_DARK);

        // ── Header ──────────────────────────────────────────────────────────
        JPanel header = new JPanel();
        header.setBackground(UITheme.BG_DARK);
        header.setBorder(new EmptyBorder(40, 30, 20, 30));
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));

        JLabel icon = new JLabel("🏨", SwingConstants.CENTER);
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 54));
        icon.setAlignmentX(CENTER_ALIGNMENT);

        JLabel title = new JLabel("Hotel Booking System", SwingConstants.CENTER);
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_PRIMARY);
        title.setAlignmentX(CENTER_ALIGNMENT);

        JLabel sub = new JLabel("Sign in to your account", SwingConstants.CENTER);
        sub.setFont(UITheme.FONT_BODY);
        sub.setForeground(UITheme.TEXT_SECONDARY);
        sub.setAlignmentX(CENTER_ALIGNMENT);

        header.add(icon);
        header.add(Box.createVerticalStrut(10));
        header.add(title);
        header.add(Box.createVerticalStrut(4));
        header.add(sub);

        // ── Form ─────────────────────────────────────────────────────────────
        JPanel form = new JPanel();
        form.setBackground(UITheme.BG_PANEL);
        form.setBorder(new EmptyBorder(30, 40, 30, 40));
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));

        usernameField = styledField("Username");
        passwordField = new JPasswordField();
        stylePasswordField(passwordField, "Password");

        JButton loginBtn = new JButton("Sign In");
        UITheme.applyPrimaryButton(loginBtn);
        loginBtn.setAlignmentX(CENTER_ALIGNMENT);
        loginBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        loginBtn.addActionListener(this::onLogin);

        JButton registerBtn = new JButton("Create Account");
        registerBtn.setBackground(UITheme.BG_CARD);
        registerBtn.setForeground(UITheme.TEXT_SECONDARY);
        registerBtn.setFont(UITheme.FONT_BUTTON);
        registerBtn.setFocusPainted(false);
        registerBtn.setBorderPainted(false);
        registerBtn.setOpaque(true);
        registerBtn.setAlignmentX(CENTER_ALIGNMENT);
        registerBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        registerBtn.addActionListener(e -> new RegisterPanel(this).setVisible(true));

        statusLabel = new JLabel(" ", SwingConstants.CENTER);
        statusLabel.setFont(UITheme.FONT_SMALL);
        statusLabel.setForeground(UITheme.DANGER);
        statusLabel.setAlignmentX(CENTER_ALIGNMENT);

        form.add(fieldLabel("Username"));
        form.add(Box.createVerticalStrut(4));
        form.add(usernameField);
        form.add(Box.createVerticalStrut(14));
        form.add(fieldLabel("Password"));
        form.add(Box.createVerticalStrut(4));
        form.add(passwordField);
        form.add(Box.createVerticalStrut(20));
        form.add(loginBtn);
        form.add(Box.createVerticalStrut(10));
        JButton adminBtn = new JButton("TERMINATE SESSION");
        adminBtn.setBackground(UITheme.PRIMARY_DARK);
        adminBtn.setForeground(Color.WHITE);
        adminBtn.setFont(UITheme.FONT_BUTTON);
        adminBtn.setFocusPainted(false);
        adminBtn.setBorderPainted(false);
        adminBtn.setOpaque(true);
        adminBtn.setAlignmentX(CENTER_ALIGNMENT);
        adminBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        adminBtn.addActionListener(e -> { setVisible(false); new AdminLoginPanel().setVisible(true); });

        form.add(registerBtn);
        form.add(Box.createVerticalStrut(10));
        form.add(adminBtn);
        form.add(Box.createVerticalStrut(12));
        form.add(statusLabel);

        root.add(header, BorderLayout.NORTH);
        root.add(form,   BorderLayout.CENTER);
        setContentPane(root);
    }

    private void onLogin(ActionEvent e) {
        String user = usernameField.getText().trim();
        String pass = new String(passwordField.getPassword());
        try {
            Customer c = authService.login(user, pass);
            setVisible(false);
            if (c.isAdmin()) {
                new AdminDashboard(authService).setVisible(true);
            } else {
                new CustomerDashboard(authService).setVisible(true);
            }
        } catch (Exception ex) {
            statusLabel.setText(ex.getMessage());
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private JTextField styledField(String placeholder) {
        JTextField f = new JTextField();
        f.setBackground(UITheme.BG_CARD);
        f.setForeground(UITheme.TEXT_PRIMARY);
        f.setCaretColor(UITheme.TEXT_PRIMARY);
        f.setFont(UITheme.FONT_BODY);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER_COLOR),
                new EmptyBorder(8, 10, 8, 10)));
        f.setMaximumSize(new Dimension(500, 40));
        f.setAlignmentX(CENTER_ALIGNMENT);
        return f;
    }

    private void stylePasswordField(JPasswordField f, String placeholder) {
        f.setBackground(UITheme.BG_CARD);
        f.setForeground(UITheme.TEXT_PRIMARY);
        f.setCaretColor(UITheme.TEXT_PRIMARY);
        f.setFont(UITheme.FONT_BODY);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER_COLOR),
                new EmptyBorder(8, 10, 8, 10)));
        f.setMaximumSize(new Dimension( 500,40));
    
        f.setAlignmentX(CENTER_ALIGNMENT);

    }

    private JLabel fieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(UITheme.TEXT_SECONDARY);
        l.setFont(UITheme.FONT_SMALL);
        l.setAlignmentX(CENTER_ALIGNMENT);
        return l;
    }
}

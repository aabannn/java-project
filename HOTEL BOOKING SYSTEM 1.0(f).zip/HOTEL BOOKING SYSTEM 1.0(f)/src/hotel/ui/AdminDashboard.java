package hotel.ui;

import hotel.dao.CustomerDAO;
import hotel.model.Booking;
import hotel.model.Customer;
import hotel.model.Payment;
import hotel.model.Room;
import hotel.service.AuthService;
import hotel.service.BookingService;
import hotel.service.RoomService;
import hotel.dao.PaymentDAO;
import hotel.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Admin Dashboard – tabbed interface for all admin operations.
 */
public class AdminDashboard extends JFrame {

    private final AuthService   authService   = new AuthService();
    private final BookingService bookingService = new BookingService();
    private final RoomService   roomService   = new RoomService();
    private final PaymentDAO    paymentDAO    = new PaymentDAO();
    private final CustomerDAO   customerDAO   = new CustomerDAO();

    public AdminDashboard(AuthService auth) {
        setTitle("🏨  Hotel Booking System – Admin Panel");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1100, 680);
        setLocationRelativeTo(null);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.BG_DARK);

        // ── Top bar ──────────────────────────────────────────────────────────
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(UITheme.BG_PANEL);
        topBar.setBorder(new EmptyBorder(12, 20, 12, 20));

        JLabel title = new JLabel("🏨  Admin Control Panel");
        title.setFont(UITheme.FONT_HEADER);
        title.setForeground(UITheme.TEXT_PRIMARY);

        Customer me = AuthService.getCurrentUser();
        JLabel userLabel = new JLabel("Logged in: " + (me != null ? me.getName() : "Admin"));
        userLabel.setForeground(UITheme.TEXT_SECONDARY);
        userLabel.setFont(UITheme.FONT_SMALL);

        JButton logoutBtn = new JButton("Logout");
        UITheme.applyDangerButton(logoutBtn);
        logoutBtn.addActionListener(e -> {
            authService.logout();
            dispose();
            new LoginPanel().setVisible(true);
        });

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        right.setOpaque(false);
        right.add(userLabel);
        right.add(logoutBtn);

        topBar.add(title, BorderLayout.WEST);
        topBar.add(right, BorderLayout.EAST);

        // ── Tabs ─────────────────────────────────────────────────────────────
        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(UITheme.BG_DARK);
        tabs.setForeground(UITheme.TEXT_PRIMARY);
        tabs.setFont(UITheme.FONT_BODY);

        tabs.addTab("📊  Dashboard",  buildDashboardTab());
        tabs.addTab("🛏  Rooms",       buildRoomsTab());
        tabs.addTab("📋  Bookings",    buildBookingsTab());
        tabs.addTab("👥  Customers",   buildCustomersTab());
        tabs.addTab("💳  Payments",    buildPaymentsTab());

        root.add(topBar, BorderLayout.NORTH);
        root.add(tabs,   BorderLayout.CENTER);
        setContentPane(root);
    }

    // ── DASHBOARD TAB ────────────────────────────────────────────────────────

    private JPanel buildDashboardTab() {
        JPanel p = new JPanel(new GridLayout(2, 3, 16, 16));
        p.setBackground(UITheme.BG_DARK);
        p.setBorder(new EmptyBorder(24, 24, 24, 24));

        List<Room>    rooms    = roomService.getAllRooms();
        List<Booking> bookings = bookingService.getAllBookings();
        long available  = rooms.stream().filter(Room::isAvailable).count();
        long booked     = rooms.stream().filter(r -> r.getStatus() == Room.Status.BOOKED).count();
        long confirmed  = bookings.stream().filter(b -> b.getStatus() == Booking.Status.CONFIRMED).count();
        long cancelled  = bookings.stream().filter(b -> b.getStatus() == Booking.Status.CANCELLED).count();
        double revenue  = paymentDAO.getTotalRevenue();

        p.add(statCard("Total Rooms",       String.valueOf(rooms.size()),     UITheme.PRIMARY));
        p.add(statCard("Available",         String.valueOf(available),        UITheme.SUCCESS));
        p.add(statCard("Booked",            String.valueOf(booked),           UITheme.WARNING));
        p.add(statCard("Total Bookings",    String.valueOf(bookings.size()),  UITheme.PRIMARY));
        p.add(statCard("Confirmed",         String.valueOf(confirmed),        UITheme.SUCCESS));
        p.add(statCard("Revenue (₹)",       String.format("%.2f", revenue),  UITheme.ACCENT));
        return p;
    }

    private JPanel statCard(String label, String value, Color accent) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(UITheme.BG_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(accent, 2),
                new EmptyBorder(20, 20, 20, 20)));
        JLabel v = new JLabel(value, SwingConstants.CENTER);
        v.setFont(new Font("Segoe UI", Font.BOLD, 32));
        v.setForeground(accent);
        JLabel l = new JLabel(label, SwingConstants.CENTER);
        l.setFont(UITheme.FONT_BODY);
        l.setForeground(UITheme.TEXT_SECONDARY);
        card.add(v, BorderLayout.CENTER);
        card.add(l, BorderLayout.SOUTH);
        return card;
    }

    // ── ROOMS TAB ────────────────────────────────────────────────────────────

    private JPanel buildRoomsTab() {
        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBackground(UITheme.BG_DARK);
        p.setBorder(new EmptyBorder(16, 16, 16, 16));

        String[] cols = {"ID", "Number", "Type", "Price/Night", "Capacity", "Status", "Amenities"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        for (Room r : roomService.getAllRooms()) {
            model.addRow(new Object[]{
                    r.getRoomId(), r.getRoomNumber(), r.getRoomType(),
                    String.format("₹%.2f", r.getPricePerNight()), r.getCapacity(),
                    r.getStatus(), r.getAmenities()
            });
        }

        JTable table = styledTable(model);
        JScrollPane scroll = new JScrollPane(table);
        styleScroll(scroll);

        JButton addBtn = new JButton("+ Add Room");
        UITheme.applyPrimaryButton(addBtn);
        addBtn.addActionListener(e -> showAddRoomDialog(model));

        JButton delBtn = new JButton("Delete Selected");
        UITheme.applyDangerButton(delBtn);
        delBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Select a room first."); return; }
            int id = (int) model.getValueAt(row, 0);
            if (roomService.deleteRoom(id)) model.removeRow(row);
        });

        JButton refreshRoomsBtn = new JButton("Refresh");
        refreshRoomsBtn.setBackground(UITheme.BG_PANEL);
        refreshRoomsBtn.setForeground(UITheme.PRIMARY);
        refreshRoomsBtn.setFont(UITheme.FONT_BUTTON);
        refreshRoomsBtn.setFocusPainted(false);
        refreshRoomsBtn.setBorderPainted(false);
        refreshRoomsBtn.setOpaque(true);
        refreshRoomsBtn.addActionListener(e -> {
            model.setRowCount(0);
            for (Room r : roomService.getAllRooms()) {
                model.addRow(new Object[]{
                    r.getRoomId(), r.getRoomNumber(), r.getRoomType(),
                    String.format("Rs.%.2f", r.getPricePerNight()), r.getCapacity(),
                    r.getStatus(), r.getAmenities()
                });
            }
        });
        
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btns.setBackground(UITheme.BG_DARK);
        btns.add(addBtn);
        btns.add(delBtn);
        btns.add(refreshRoomsBtn);

        p.add(btns,   BorderLayout.NORTH);
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    private void showAddRoomDialog(DefaultTableModel model) {
        JTextField num   = new JTextField();
        JComboBox<Room.RoomType> type = new JComboBox<>(Room.RoomType.values());
        JTextField price = new JTextField();
        JTextField cap   = new JTextField("2");
        JTextField amen  = new JTextField("WiFi, TV, AC");
        JTextField desc  = new JTextField();

        Object[] fields = {"Room Number:", num, "Type:", type, "Price/Night:", price,
                           "Capacity:", cap, "Amenities:", amen, "Description:", desc};
        int res = JOptionPane.showConfirmDialog(this, fields, "Add Room", JOptionPane.OK_CANCEL_OPTION);
        if (res == JOptionPane.OK_OPTION) {
            try {
                Room r = roomService.addRoom(num.getText(), (Room.RoomType) type.getSelectedItem(),
                        Double.parseDouble(price.getText()), Integer.parseInt(cap.getText()),
                        amen.getText(), desc.getText());
                model.addRow(new Object[]{r.getRoomId(), r.getRoomNumber(), r.getRoomType(),
                        String.format("₹%.2f", r.getPricePerNight()), r.getCapacity(),
                        r.getStatus(), r.getAmenities()});
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // ── BOOKINGS TAB ─────────────────────────────────────────────────────────

    private JPanel buildBookingsTab() {
        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBackground(UITheme.BG_DARK);
        p.setBorder(new EmptyBorder(16, 16, 16, 16));

        String[] cols = {"ID", "Customer", "Room", "Check-In", "Check-Out", "Amount", "Status"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        for (Booking b : bookingService.getAllBookings()) {
            model.addRow(new Object[]{
                    b.getBookingId(), b.getCustomerName(), b.getRoomNumber(),
                    b.getCheckInDate(), b.getCheckOutDate(),
                    String.format("₹%.2f", b.getTotalAmount()), b.getStatus()
            });
        }

        JTable table = styledTable(model);

        JButton cancelBtn = new JButton("Cancel Booking");
        UITheme.applyDangerButton(cancelBtn);
        cancelBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Select a booking."); return; }
            int id = (int) model.getValueAt(row, 0);
            try {
                bookingService.cancel(id);
                model.setValueAt(Booking.Status.CANCELLED, row, 6);
                JOptionPane.showMessageDialog(this, "Booking cancelled.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton refreshBookingsBtn = new JButton("Refresh");
        refreshBookingsBtn.setBackground(UITheme.BG_PANEL);
        refreshBookingsBtn.setForeground(UITheme.PRIMARY);
        refreshBookingsBtn.setFont(UITheme.FONT_BUTTON);
        refreshBookingsBtn.setFocusPainted(false);
        refreshBookingsBtn.setBorderPainted(false);
        refreshBookingsBtn.setOpaque(true);
        refreshBookingsBtn.addActionListener(e -> {
            model.setRowCount(0);
            for (Booking b : bookingService.getAllBookings()) {
                model.addRow(new Object[]{
                    b.getBookingId(), b.getCustomerName(), b.getRoomNumber(),
                    b.getCheckInDate(), b.getCheckOutDate(),
                    String.format("Rs.%.2f", b.getTotalAmount()), b.getStatus()
                });
            }
        });
        
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btns.setBackground(UITheme.BG_DARK);
        btns.add(cancelBtn);
        btns.add(refreshBookingsBtn);

        p.add(btns, BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        styleScroll((JScrollPane) p.getComponent(1));
        return p;
    }

    // ── CUSTOMERS TAB ────────────────────────────────────────────────────────

    private JPanel buildCustomersTab() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(UITheme.BG_DARK);
        p.setBorder(new EmptyBorder(16, 16, 16, 16));
    
        String[] cols = {"ID", "Name", "Email", "Phone", "Role", "Active"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
    
        for (Customer c : customerDAO.findAll()) {
            model.addRow(new Object[]{
                    c.getCustomerId(), c.getName(), c.getEmail(),
                    c.getPhone(), c.getRole(), c.isActive() ? "Yes" : "No"
            });
        }
    
        JTable table = styledTable(model);
        JScrollPane scroll = new JScrollPane(table);
        styleScroll(scroll);
    
        // Edit Button
        JButton editBtn = new JButton("Edit");
        UITheme.applyPrimaryButton(editBtn);
        editBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Select a customer first."); return; }
            int id       = (int)    model.getValueAt(row, 0);
            String name  = (String) model.getValueAt(row, 1);
            String email = (String) model.getValueAt(row, 2);
            String phone = (String) model.getValueAt(row, 3);
    
            JTextField nameF  = new JTextField(name);
            JTextField emailF = new JTextField(email);
            JTextField phoneF = new JTextField(phone);
    
            Object[] fields = {"Name:", nameF, "Email:", emailF, "Phone:", phoneF};
            int res = JOptionPane.showConfirmDialog(this, fields, "Edit Customer", JOptionPane.OK_CANCEL_OPTION);
            if (res == JOptionPane.OK_OPTION) {
                try {
                    customerDAO.updateCustomer(id, nameF.getText(), emailF.getText(), phoneF.getText());
                    model.setValueAt(nameF.getText(),  row, 1);
                    model.setValueAt(emailF.getText(), row, 2);
                    model.setValueAt(phoneF.getText(), row, 3);
                    JOptionPane.showMessageDialog(this, "Customer updated!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    
        // Delete Button
        JButton deleteBtn = new JButton("Delete");
        UITheme.applyDangerButton(deleteBtn);
        deleteBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Select a customer first."); return; }
            int id = (int) model.getValueAt(row, 0);
            int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete this customer?",
                    "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    customerDAO.deleteCustomer(id);
                    model.removeRow(row);
                    JOptionPane.showMessageDialog(this, "Customer deleted.");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    
        // View Bookings Button
        JButton viewBookingsBtn = new JButton("View Bookings");
        UITheme.applyPrimaryButton(viewBookingsBtn);
        viewBookingsBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Select a customer first."); return; }
            int id      = (int)    model.getValueAt(row, 0);
            String name = (String) model.getValueAt(row, 1);
    
            String[] bCols = {"Booking ID", "Room", "Type", "Check-In", "Check-Out", "Total", "Status"};
            DefaultTableModel bModel = new DefaultTableModel(bCols, 0) {
                public boolean isCellEditable(int r, int c) { return false; }
            };
            for (Booking b : bookingService.getByCustomer(id)) {
                bModel.addRow(new Object[]{
                    b.getBookingId(), b.getRoomNumber(), b.getRoomType(),
                    b.getCheckInDate(), b.getCheckOutDate(),
                    String.format("Rs.%.2f", b.getTotalAmount()), b.getStatus()
                });
            }
    
            JTable bTable = styledTable(bModel);
            JScrollPane bScroll = new JScrollPane(bTable);
            bScroll.setPreferredSize(new Dimension(700, 300));
            styleScroll(bScroll);
            JOptionPane.showMessageDialog(this, bScroll,
                    "Bookings for: " + name, JOptionPane.PLAIN_MESSAGE);
        });
    
        // Block/Unblock Button
        JButton blockBtn = new JButton("Block / Unblock");
        blockBtn.setBackground(UITheme.WARNING);
        blockBtn.setForeground(Color.WHITE);
        blockBtn.setFont(UITheme.FONT_BUTTON);
        blockBtn.setFocusPainted(false);
        blockBtn.setBorderPainted(false);
        blockBtn.setOpaque(true);
        blockBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Select a customer first."); return; }
            int id           = (int)    model.getValueAt(row, 0);
            String curStatus = (String) model.getValueAt(row, 5);
            boolean isActive = curStatus.equals("Yes");
    
            int confirm = JOptionPane.showConfirmDialog(this,
                    "Do you want to " + (isActive ? "BLOCK" : "UNBLOCK") + " this customer?",
                    "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    customerDAO.toggleActive(id, !isActive);
                    model.setValueAt(!isActive ? "Yes" : "No", row, 5);
                    JOptionPane.showMessageDialog(this,
                            "Customer " + (!isActive ? "unblocked" : "blocked") + " successfully.");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btns.setBackground(UITheme.BG_DARK);
        btns.add(editBtn);
        btns.add(deleteBtn);
        btns.add(viewBookingsBtn);
        btns.add(blockBtn);
    
        p.add(btns,   BorderLayout.NORTH);
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    // ── PAYMENTS TAB ─────────────────────────────────────────────────────────

    private JPanel buildPaymentsTab() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(UITheme.BG_DARK);
        p.setBorder(new EmptyBorder(16, 16, 16, 16));

        String[] cols = {"ID", "Booking ID", "Customer", "Amount", "Tax", "Total", "Method", "Status", "Date"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        for (Payment pay : paymentDAO.findAll()) {
            model.addRow(new Object[]{
                    pay.getPaymentId(), pay.getBookingId(), pay.getCustomerName(),
                    String.format("₹%.2f", pay.getAmount()),
                    String.format("₹%.2f", pay.getTaxAmount()),
                    String.format("₹%.2f", pay.getTotalAmount()),
                    pay.getPaymentMethod(), pay.getPaymentStatus(),
                    pay.getPaymentDate() != null ? pay.getPaymentDate().toLocalDate() : ""
            });
        }

        JTable table = styledTable(model);
        JScrollPane scroll = new JScrollPane(table);
        styleScroll(scroll);
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    // ── SHARED HELPERS ───────────────────────────────────────────────────────

    private JTable styledTable(DefaultTableModel model) {
        JTable t = new JTable(model);
        t.setBackground(UITheme.BG_CARD);
        t.setForeground(UITheme.TEXT_PRIMARY);
        t.setGridColor(UITheme.BORDER_COLOR);
        t.setFont(UITheme.FONT_BODY);
        t.setRowHeight(28);
        t.getTableHeader().setBackground(UITheme.BG_PANEL);
        t.getTableHeader().setForeground(UITheme.TEXT_SECONDARY);
        t.getTableHeader().setFont(UITheme.FONT_BUTTON);
        t.setSelectionBackground(UITheme.PRIMARY_DARK);
        t.setSelectionForeground(Color.WHITE);
        return t;
    }

    private void styleScroll(JScrollPane s) {
        s.getViewport().setBackground(UITheme.BG_CARD);
        s.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_COLOR));
    }
}

package hotel.ui;

import hotel.model.Booking;
import hotel.model.Customer;
import hotel.model.Payment;
import hotel.model.Room;
import hotel.service.AuthService;
import hotel.service.BookingService;
import hotel.service.RoomService;
import hotel.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;
import java.awt.Image;

/**
 * Customer-facing dashboard for searching rooms and managing bookings.
 */
public class CustomerDashboard extends JFrame {

    private final AuthService    authService    = new AuthService();
    private final BookingService bookingService = new BookingService();
    private final RoomService    roomService    = new RoomService();

    public CustomerDashboard(AuthService auth) {
        Customer me = AuthService.getCurrentUser();
        setTitle("🏨  Hotel Booking System – Welcome, " + (me != null ? me.getName() : "Guest"));
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1000, 640);
        setLocationRelativeTo(null);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.BG_DARK);

        // Top bar
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(UITheme.BG_PANEL);
        topBar.setBorder(new EmptyBorder(12, 20, 12, 20));
        JLabel title = new JLabel("Hotel Booking Portal");
        title.setFont(UITheme.FONT_HEADER);
        title.setForeground(UITheme.TEXT_PRIMARY);
        JButton logout = new JButton("Logout");
        UITheme.applyDangerButton(logout);
        logout.addActionListener(e -> { authService.logout(); dispose(); setVisible(false);new LoginPanel().setVisible(true); });
        topBar.add(title, BorderLayout.WEST);
        topBar.add(logout, BorderLayout.EAST);

        // Tabs
        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(UITheme.BG_DARK);
        tabs.setForeground(UITheme.TEXT_PRIMARY);
        tabs.setFont(UITheme.FONT_BODY);
        tabs.addTab("Search & Book", buildSearchTab());
        tabs.addTab("My Bookings",   buildMyBookingsTab());

        root.add(topBar, BorderLayout.NORTH);
        root.add(tabs,   BorderLayout.CENTER);
        setContentPane(root);
    }

    // ── SEARCH TAB ───────────────────────────────────────────────────────────

    private JPanel buildSearchTab() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(UITheme.BG_DARK);
        p.setBorder(new EmptyBorder(16, 16, 16, 16));

        // Search controls
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 6));
        controls.setBackground(UITheme.BG_PANEL);
        controls.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel cinL  = labelFor("Check-In (YYYY-MM-DD):");
        JLabel coutL = labelFor("Check-Out (YYYY-MM-DD):");
        JTextField cinF  = field(12);
        JTextField coutF = field(12);

        LocalDate today = LocalDate.now();
        cinF.setText(today.toString());
        coutF.setText(today.plusDays(1).toString());

        JButton searchBtn = new JButton("Search");
        UITheme.applyPrimaryButton(searchBtn);

        controls.add(cinL);  controls.add(cinF);
        controls.add(coutL); controls.add(coutF);
        controls.add(searchBtn);

        // Results table
        String[] cols = {"ID", "Room No.", "Type", "Capacity", "Price/Night", "Amenities"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = styledTable(model);
        JScrollPane scroll = new JScrollPane(table);
        styleScroll(scroll);

        searchBtn.addActionListener(e -> {
            model.setRowCount(0);
            try {
                LocalDate ci = LocalDate.parse(cinF.getText().trim());
                LocalDate co = LocalDate.parse(coutF.getText().trim());
                List<Room> rooms = roomService.getAvailableRooms(ci, co);
                if (rooms.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "No rooms available for those dates.");
                } else {
                    for (Room r : rooms) {
                        model.addRow(new Object[]{r.getRoomId(), r.getRoomNumber(),
                                r.getRoomType(), r.getCapacity(),
                                String.format("₹%.2f", r.getPricePerNight()), r.getAmenities()});
                    }
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid date: " + ex.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Book button
        JButton bookBtn = new JButton("Book Selected Room");
        UITheme.applyPrimaryButton(bookBtn);
        bookBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Select a room first."); return; }
            try {
                int roomId = (int) model.getValueAt(row, 0);
                LocalDate ci = LocalDate.parse(cinF.getText().trim());
                LocalDate co = LocalDate.parse(coutF.getText().trim());
                showBookingDialog(roomId, ci, co);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottom.setBackground(UITheme.BG_DARK);
        bottom.add(bookBtn);

        p.add(controls, BorderLayout.NORTH);
        p.add(scroll,   BorderLayout.CENTER);
        p.add(bottom,   BorderLayout.SOUTH);
        return p;
    }

    private void showBookingDialog(int roomId, LocalDate ci, LocalDate co) {
        Room room = roomService.getRoomById(roomId);
        long nights = java.time.temporal.ChronoUnit.DAYS.between(ci, co);
        double total = nights * room.getPricePerNight();

        String[] methods = {"CASH", "CARD", "ONLINE"};
        JComboBox<String> methodBox = new JComboBox<>(methods);
        JTextField reqField = new JTextField();

        String info = String.format(
                "<html><b>Room:</b> %s (%s)<br><b>Check-in:</b> %s<br>"
              + "<b>Check-out:</b> %s<br><b>Nights:</b> %d<br>"
              + "<b>Total:</b> ₹%.2f + 10%% tax</html>",
                room.getRoomNumber(), room.getRoomType(), ci, co, nights, total);

        Object[] fields = {info, "Payment Method:", methodBox, "Special Requests:", reqField};
        int res = JOptionPane.showConfirmDialog(this, fields, "Confirm Booking", JOptionPane.OK_CANCEL_OPTION);
        if ("ONLINE".equals(methodBox.getSelectedItem())) {
            ImageIcon qrIcon = new ImageIcon("C:\\Users\\abana\\Pictures\\mea\\HotelBookingSystem\\src\\hotel\\ui\\qr_code.jpeg");
            Image scaled = qrIcon.getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH);
            JLabel qrLabel = new JLabel(new ImageIcon(scaled));
        
            JLabel amtLabel = new JLabel(
                String.format("Amount to Pay: ₹%.2f (incl. 10%% tax)", total * 1.1),
                SwingConstants.CENTER);
            amtLabel.setFont(UITheme.FONT_HEADER);
        
            JLabel instrLabel = new JLabel("Scan with GPay / PhonePe / Paytm", SwingConstants.CENTER);
            instrLabel.setFont(UITheme.FONT_BODY);
        
            JPanel qrPanel = new JPanel(new BorderLayout(10, 10));
            qrPanel.add(amtLabel,   BorderLayout.NORTH);
            qrPanel.add(qrLabel,    BorderLayout.CENTER);
            qrPanel.add(instrLabel, BorderLayout.SOUTH);
        
            JOptionPane.showMessageDialog(this, qrPanel, "Scan QR to Pay", JOptionPane.PLAIN_MESSAGE);
        }
        if (res == JOptionPane.OK_OPTION) {
            try {
                Customer me = AuthService.getCurrentUser();
                Payment.Method method = Payment.Method.valueOf((String) methodBox.getSelectedItem());
                Booking b = bookingService.book(me.getCustomerId(), roomId, ci, co, method, reqField.getText());
                JOptionPane.showMessageDialog(this,
                        "✅ Booking confirmed!\nBooking ID: #" + b.getBookingId()
                        + "\nTotal: ₹" + String.format("%.2f", b.getTotalAmount() * 1.1),
                        "Booking Confirmed", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // ── MY BOOKINGS TAB ──────────────────────────────────────────────────────

    private JPanel buildMyBookingsTab() {
        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBackground(UITheme.BG_DARK);
        p.setBorder(new EmptyBorder(16, 16, 16, 16));

        String[] cols = {"Booking ID", "Room", "Type", "Check-In", "Check-Out", "Total", "Status"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        Customer me = AuthService.getCurrentUser();
        if (me != null) {
            for (Booking b : bookingService.getByCustomer(me.getCustomerId())) {
                model.addRow(new Object[]{
                        b.getBookingId(), b.getRoomNumber(), b.getRoomType(),
                        b.getCheckInDate(), b.getCheckOutDate(),
                        String.format("₹%.2f", b.getTotalAmount()), b.getStatus()
                });
            }
        }

        JTable table = styledTable(model);

        JButton cancelBtn = new JButton("Cancel Booking");
        UITheme.applyDangerButton(cancelBtn);
        cancelBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Select a booking."); return; }
            int id = (int) model.getValueAt(row, 0);
            try {
                bookingService.cancel(id);
                model.removeRow(row);
                JOptionPane.showMessageDialog(this, "Booking cancelled.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton refreshBookingsBtn = new JButton("Refresh");
        refreshBookingsBtn.setBackground(UITheme.BG_PANEL);
        refreshBookingsBtn.setForeground(UITheme.PRIMARY);
        refreshBookingsBtn.setFont(UITheme.FONT_BUTTON);
        refreshBookingsBtn.setFocusPainted(false);
        refreshBookingsBtn.setBorderPainted(false);
        refreshBookingsBtn.setOpaque(true);
        refreshBookingsBtn.addActionListener(e -> {
            model.setRowCount(0);
            Customer me2 = AuthService.getCurrentUser();
            if (me2 != null) {
                for (Booking b : bookingService.getByCustomer(me2.getCustomerId())) {
                    model.addRow(new Object[]{
                        b.getBookingId(), b.getRoomNumber(), b.getRoomType(),
                        b.getCheckInDate(), b.getCheckOutDate(),
                        String.format("Rs.%.2f", b.getTotalAmount()), b.getStatus()
                    });
                }
            }
        });
        
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btns.setBackground(UITheme.BG_DARK);
        btns.add(cancelBtn);
        btns.add(refreshBookingsBtn);

        p.add(btns, BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        JButton refreshBtn = new JButton("Refresh Rooms");
        refreshBtn.setBackground(UITheme.BG_PANEL);
        refreshBtn.setForeground(UITheme.PRIMARY);
        refreshBtn.setFont(UITheme.FONT_BUTTON);
        refreshBtn.setFocusPainted(false);
        refreshBtn.setBorderPainted(false);
        refreshBtn.setOpaque(true);
        refreshBtn.addActionListener(e -> {
            model.setRowCount(0);
            Customer me2 = AuthService.getCurrentUser();
            if (me2 != null) {
                for (Booking b : bookingService.getByCustomer(me2.getCustomerId())) {
                    model.addRow(new Object[]{
                        b.getBookingId(), b.getRoomNumber(), b.getRoomType(),
                        b.getCheckInDate(), b.getCheckOutDate(),
                        String.format("Rs.%.2f", b.getTotalAmount()), b.getStatus()
                    });
                }
            }
        });

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottom.setBackground(UITheme.BG_DARK);
        bottom.add(refreshBtn);
        p.add(bottom, BorderLayout.SOUTH);
        return p;
    }

    // ── HELPERS ──────────────────────────────────────────────────────────────

    private JTable styledTable(DefaultTableModel model) {
        JTable t = new JTable(model);
        t.setBackground(UITheme.BG_CARD);
        t.setForeground(UITheme.TEXT_PRIMARY);
        t.setGridColor(UITheme.BORDER_COLOR);
        t.setFont(UITheme.FONT_BODY);
        t.setRowHeight(28);
        t.getTableHeader().setBackground(UITheme.BG_PANEL);
        t.getTableHeader().setForeground(UITheme.TEXT_SECONDARY);
        t.getTableHeader().setFont(UITheme.FONT_BUTTON);
        t.setSelectionBackground(UITheme.PRIMARY_DARK);
        t.setSelectionForeground(Color.WHITE);
        return t;
    }

    private void styleScroll(JScrollPane s) {
        s.getViewport().setBackground(UITheme.BG_CARD);
        s.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_COLOR));
    }

    private JLabel labelFor(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(UITheme.TEXT_SECONDARY);
        l.setFont(UITheme.FONT_SMALL);
        return l;
    }

    private JTextField field(int cols) {
        JTextField f = new JTextField(cols);
        f.setBackground(UITheme.BG_CARD);
        f.setForeground(UITheme.TEXT_PRIMARY);
        f.setCaretColor(UITheme.TEXT_PRIMARY);
        f.setFont(UITheme.FONT_BODY);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER_COLOR),
                new EmptyBorder(5, 8, 5, 8)));
        return f;
    }
}

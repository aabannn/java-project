package hotel.ui;

import hotel.model.Customer;
import hotel.service.AuthService;
import hotel.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class AdminLoginPanel extends JFrame {

    private final AuthService authService = new AuthService();

    private JTextField     usernameField;
    private JPasswordField passwordField;
    private JLabel         statusLabel;

    public AdminLoginPanel() {
        setTitle("Hotel Booking System - Admin Login");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(460, 520);
        setLocationRelativeTo(null);
        setResizable(false);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.BG_DARK);

        // ── Header ──────────────────────────────────────────────
        JPanel header = new JPanel();
        header.setBackground(UITheme.PRIMARY_DARK);
        header.setBorder(new EmptyBorder(40, 30, 20, 30));
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));

        JLabel icon = new JLabel("ADMIN", SwingConstants.CENTER);
        icon.setFont(new Font("Segoe UI", Font.BOLD, 36));
        icon.setForeground(Color.WHITE);
        icon.setAlignmentX(CENTER_ALIGNMENT);

        JLabel title = new JLabel("Admin Portal", SwingConstants.CENTER);
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(Color.WHITE);
        title.setAlignmentX(CENTER_ALIGNMENT);

        JLabel sub = new JLabel("Sign in with your admin credentials", SwingConstants.CENTER);
        sub.setFont(UITheme.FONT_BODY);
        sub.setForeground(new Color(0xBB, 0xDE, 0xFB));
        sub.setAlignmentX(CENTER_ALIGNMENT);

        header.add(icon);
        header.add(Box.createVerticalStrut(10));
        header.add(title);
        header.add(Box.createVerticalStrut(4));
        header.add(sub);

        // ── Form ────────────────────────────────────────────────
        JPanel form = new JPanel();
        form.setBackground(UITheme.BG_PANEL);
        form.setBorder(new EmptyBorder(30, 40, 30, 40));
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));

        usernameField = new JTextField();
        usernameField.setBackground(UITheme.BG_DARK);
        usernameField.setForeground(UITheme.TEXT_PRIMARY);
        usernameField.setCaretColor(UITheme.TEXT_PRIMARY);
        usernameField.setFont(UITheme.FONT_BODY);
        usernameField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER_COLOR),
                new EmptyBorder(8, 10, 8, 10)));
        usernameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        passwordField = new JPasswordField();
        passwordField.setBackground(UITheme.BG_DARK);
        passwordField.setForeground(UITheme.TEXT_PRIMARY);
        passwordField.setCaretColor(UITheme.TEXT_PRIMARY);
        passwordField.setFont(UITheme.FONT_BODY);
        passwordField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER_COLOR),
                new EmptyBorder(8, 10, 8, 10)));
        passwordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        passwordField.setAlignmentX(LEFT_ALIGNMENT);

        JButton loginBtn = new JButton("Sign In as Admin");
        UITheme.applyPrimaryButton(loginBtn);
        loginBtn.setAlignmentX(CENTER_ALIGNMENT);
        loginBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        loginBtn.addActionListener(e -> onLogin());

        JButton backBtn = new JButton("Back to Customer Login");
        backBtn.setBackground(UITheme.BG_PANEL);
        backBtn.setForeground(UITheme.PRIMARY);
        backBtn.setFont(UITheme.FONT_BUTTON);
        backBtn.setFocusPainted(false);
        backBtn.setBorderPainted(false);
        backBtn.setOpaque(true);
        backBtn.setAlignmentX(CENTER_ALIGNMENT);
        backBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        backBtn.addActionListener(e -> { dispose(); new LoginPanel().setVisible(true); });

        statusLabel = new JLabel(" ", SwingConstants.CENTER);
        statusLabel.setFont(UITheme.FONT_SMALL);
        statusLabel.setForeground(UITheme.DANGER);
        statusLabel.setAlignmentX(CENTER_ALIGNMENT);

        form.add(fieldLabel("Username"));
        form.add(Box.createVerticalStrut(4));
        form.add(usernameField);
        form.add(Box.createVerticalStrut(14));
        form.add(fieldLabel("Password"));
        form.add(Box.createVerticalStrut(4));
        form.add(passwordField);
        form.add(Box.createVerticalStrut(20));
        form.add(loginBtn);
        form.add(Box.createVerticalStrut(10));
        form.add(backBtn);
        form.add(Box.createVerticalStrut(12));
        form.add(statusLabel);

        root.add(header, BorderLayout.NORTH);
        root.add(form,   BorderLayout.CENTER);
        setContentPane(root);
    }

    private void onLogin() {
        String user = usernameField.getText().trim();
        String pass = new String(passwordField.getPassword());
        try {
            Customer c = authService.login(user, pass);
            if (!c.isAdmin()) {
                statusLabel.setText("Access denied. Not an admin account.");
                return;
            }
            dispose();
            new AdminDashboard(authService).setVisible(true);
        } catch (Exception ex) {
            statusLabel.setText(ex.getMessage());
        }
    }

    private JLabel fieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(UITheme.TEXT_SECONDARY);
        l.setFont(UITheme.FONT_SMALL);
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }
}
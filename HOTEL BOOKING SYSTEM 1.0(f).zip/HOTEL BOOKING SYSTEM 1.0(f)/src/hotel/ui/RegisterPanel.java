package hotel.ui;

import hotel.service.AuthService;
import hotel.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Registration form for new customers.
 */
public class RegisterPanel extends JDialog {

    private final AuthService authService = new AuthService();

    private JTextField     nameField, emailField, phoneField, addressField, usernameField;
    private JPasswordField passwordField;
    private JLabel         statusLabel;

    public RegisterPanel(JFrame parent) {
        super(parent, "Create Account", true);
        setSize(480, 580);
        setLocationRelativeTo(parent);
        setResizable(false);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.BG_DARK);

        JLabel title = new JLabel("  Create New Account");
        title.setFont(UITheme.FONT_HEADER);
        title.setForeground(UITheme.TEXT_PRIMARY);
        title.setOpaque(true);
        title.setBackground(UITheme.BG_PANEL);
        title.setBorder(new EmptyBorder(18, 20, 18, 20));

        JPanel form = new JPanel(new GridLayout(0, 1, 6, 6));
        form.setBackground(UITheme.BG_DARK);
        form.setBorder(new EmptyBorder(20, 30, 10, 30));

        nameField     = addRow(form, "Full Name");
        emailField    = addRow(form, "Email");
        phoneField    = addRow(form, "Phone");
        addressField  = addRow(form, "Address");
        usernameField = addRow(form, "Username");

        form.add(label("Password"));
        passwordField = new JPasswordField();
        styleField(passwordField);
        form.add(passwordField);

        statusLabel = new JLabel(" ");
        statusLabel.setForeground(UITheme.DANGER);
        statusLabel.setFont(UITheme.FONT_SMALL);
        form.add(statusLabel);

        JButton btn = new JButton("Register");
        UITheme.applyPrimaryButton(btn);
        btn.addActionListener(e -> onRegister());

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottom.setBackground(UITheme.BG_DARK);
        bottom.setBorder(new EmptyBorder(0, 0, 20, 0));
        bottom.add(btn);

        root.add(title,  BorderLayout.NORTH);
        root.add(form,   BorderLayout.CENTER);
        root.add(bottom, BorderLayout.SOUTH);
        setContentPane(root);
    }

    private void onRegister() {
        try {
            authService.register(
                    nameField.getText().trim(),
                    emailField.getText().trim(),
                    phoneField.getText().trim(),
                    addressField.getText().trim(),
                    usernameField.getText().trim(),
                    new String(passwordField.getPassword()));
            JOptionPane.showMessageDialog(this, "Account created! You can now log in.",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } catch (Exception ex) {
            statusLabel.setText(ex.getMessage());
        }
    }

    private JTextField addRow(JPanel panel, String labelText) {
        panel.add(label(labelText));
        JTextField f = new JTextField();
        styleField(f);
        panel.add(f);
        return f;
    }

    private JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(UITheme.TEXT_SECONDARY);
        l.setFont(UITheme.FONT_SMALL);
        return l;
    }

    private void styleField(JTextField f) {
        f.setBackground(UITheme.BG_CARD);
        f.setForeground(UITheme.TEXT_PRIMARY);
        f.setCaretColor(UITheme.TEXT_PRIMARY);
        f.setFont(UITheme.FONT_BODY);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER_COLOR),
                new EmptyBorder(6, 8, 6, 8)));
    }
}

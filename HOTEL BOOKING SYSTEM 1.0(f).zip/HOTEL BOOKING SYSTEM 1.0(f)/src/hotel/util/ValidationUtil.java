package hotel.util;

import java.time.LocalDate;
import java.util.regex.Pattern;

/**
 * Input validation helpers used across service and UI layers.
 */
public class ValidationUtil {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    private static final Pattern PHONE_PATTERN =
            Pattern.compile("^[0-9]{7,15}$");

    private ValidationUtil() {}

    public static boolean isValidEmail(String email) {
        return email != null && EMAIL_PATTERN.matcher(email.trim()).matches();
    }

    public static boolean isValidPhone(String phone) {
        return phone != null && PHONE_PATTERN.matcher(phone.trim()).matches();
    }

    public static boolean isNotBlank(String s) {
        return s != null && !s.trim().isEmpty();
    }

    public static boolean isValidPassword(String pwd) {
        return pwd != null && pwd.length() >= 6;
    }

    public static boolean isValidDateRange(LocalDate checkIn, LocalDate checkOut) {
        if (checkIn == null || checkOut == null) return false;
        return !checkIn.isBefore(LocalDate.now()) && checkOut.isAfter(checkIn);
    }

    public static boolean isPositive(double value) {
        return value > 0;
    }
}

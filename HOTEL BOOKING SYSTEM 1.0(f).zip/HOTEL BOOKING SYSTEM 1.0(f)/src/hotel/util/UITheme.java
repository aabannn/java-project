package hotel.util;

import java.awt.*;

/**
 * Centralized colour and font constants for consistent UI styling.
 */
public class UITheme {

    // Palette
    public static final Color PRIMARY        = new Color(0x19, 0x76, 0xD2);
    public static final Color PRIMARY_DARK   = new Color(0x0D, 0x47, 0xA1);
    public static final Color ACCENT         = new Color(0x03, 0xA9, 0xF4);
    public static final Color SUCCESS        = new Color(0x2E, 0x7D, 0x32);
    public static final Color DANGER         = new Color(0xC6, 0x28, 0x28);
    public static final Color WARNING        = new Color(0xF5, 0x7F, 0x17);
    
    public static final Color BG_DARK        = new Color(0xE3, 0xF2, 0xFD);
    public static final Color BG_PANEL       = new Color(0xBB, 0xDE, 0xFB);
    public static final Color BG_CARD        = new Color(0xFF, 0xFF, 0xFF);
    public static final Color TEXT_PRIMARY   = new Color(0x0D, 0x1B, 0x2A);
    public static final Color TEXT_SECONDARY = new Color(0x37, 0x47, 0x5A);
    public static final Color BORDER_COLOR   = new Color(0x90, 0xCA, 0xF9);

    // Fonts
    public static final Font FONT_TITLE  = new Font("Segoe UI", Font.BOLD, 24);
    public static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 16);
    public static final Font FONT_BODY   = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_SMALL  = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 13);

    private UITheme() {}

    /** Styles a JButton with PRIMARY colour scheme. */
    public static void applyPrimaryButton(javax.swing.JButton btn) {
        btn.setBackground(PRIMARY);
        btn.setForeground(Color.WHITE);
        btn.setFont(FONT_BUTTON);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setOpaque(true);
    }

    public static void applyDangerButton(javax.swing.JButton btn) {
        btn.setBackground(DANGER);
        btn.setForeground(Color.WHITE);
        btn.setFont(FONT_BUTTON);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setOpaque(true);
    }
}

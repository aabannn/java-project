package hotel;

import hotel.config.DatabaseConnection;
import hotel.ui.LoginPanel;
import hotel.util.UITheme;

import javax.swing.*;

/**
 * ╔══════════════════════════════════════════════════════════╗
 * ║          Hotel Booking System – Entry Point              ║
 * ║  Course : Java  |  College : MEA                         ║
 * ║  Team   : Shahin, Aban, Ajmal, Shamnoon                  ║
 * ╚══════════════════════════════════════════════════════════╝
 *
 * Run this class to launch the application.
 * Ensure MySQL is running and hotel_booking_db exists (run hotel_schema.sql first).
 */
public class Main {

    public static void main(String[] args) {

        // Apply system look-and-feel for native widgets where possible
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        // Verify DB connection at startup
        try {
            DatabaseConnection.getInstance();
        } catch (RuntimeException e) {
            JOptionPane.showMessageDialog(null,
                    "❌  Cannot connect to the database.\n\n"
                    + "Please ensure:\n"
                    + "  1. MySQL server is running.\n"
                    + "  2. You have run  sql/hotel_schema.sql.\n"
                    + "  3. Credentials in DatabaseConfig.java are correct.\n\n"
                    + "Error: " + e.getCause().getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        // Launch on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            LoginPanel login = new LoginPanel();
            login.setVisible(true);
        });

        // Ensure connection is closed when the JVM exits
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            DatabaseConnection.closeConnection();
            System.out.println("Application shutdown complete.");
        }));
    }
}

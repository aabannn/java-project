package hotel.service;

import hotel.dao.BookingDAO;
import hotel.dao.PaymentDAO;
import hotel.dao.RoomDAO;
import hotel.model.Booking;
import hotel.model.Payment;
import hotel.model.Room;
import hotel.util.ValidationUtil;

import java.time.LocalDate;
import java.util.List;

/**
 * Business logic for creating, cancelling, and querying bookings.
 */
public class BookingService {

    private final BookingDAO bookingDAO = new BookingDAO();
    private final RoomDAO    roomDAO    = new RoomDAO();
    private final PaymentDAO paymentDAO = new PaymentDAO();

    /**
     * Creates a booking and records a payment atomically.
     * Returns the new Booking with its generated ID.
     */
    public Booking book(int customerId, int roomId,
                        LocalDate checkIn, LocalDate checkOut,
                        Payment.Method paymentMethod, String specialRequests) {

        if (!ValidationUtil.isValidDateRange(checkIn, checkOut)) {
            throw new IllegalArgumentException("Invalid date range.");
        }

        Room room = roomDAO.findById(roomId);
        if (room == null || !room.isAvailable()) {
            throw new IllegalStateException("Room is not available.");
        }

        // Re-check availability against existing bookings
        List<Room> available = roomDAO.findAvailable(checkIn, checkOut);
        boolean stillAvailable = available.stream().anyMatch(r -> r.getRoomId() == roomId);
        if (!stillAvailable) {
            throw new IllegalStateException("Room already booked for those dates.");
        }

        long nights = java.time.temporal.ChronoUnit.DAYS.between(checkIn, checkOut);
        double total = nights * room.getPricePerNight();

        Booking booking = new Booking(customerId, roomId, checkIn, checkOut, total, specialRequests);

        if (!bookingDAO.create(booking)) {
            throw new RuntimeException("Failed to create booking.");
        }

        // Create payment record
        Payment payment = new Payment(booking.getBookingId(), total, paymentMethod);
        paymentDAO.create(payment);

        // Mark room as booked
        roomDAO.updateStatus(roomId, Room.Status.BOOKED);

        System.out.println("[BookingService] Created: " + booking);
        return booking;
    }

    /** Cancels a booking and frees the room. */
    public boolean cancel(int bookingId) {
        Booking b = bookingDAO.findById(bookingId);
        if (b == null) throw new IllegalArgumentException("Booking not found.");
        if (b.getStatus() == Booking.Status.CANCELLED) {
            throw new IllegalStateException("Already cancelled.");
        }
        bookingDAO.updateStatus(bookingId, Booking.Status.CANCELLED);
        roomDAO.updateStatus(b.getRoomId(), Room.Status.AVAILABLE);
        System.out.println("[BookingService] Cancelled booking #" + bookingId);
        return true;
    }

    public List<Booking> getAllBookings()                    { return bookingDAO.findAll(); }
    public List<Booking> getByCustomer(int customerId)      { return bookingDAO.findByCustomer(customerId); }
    public Booking       getById(int bookingId)             { return bookingDAO.findById(bookingId); }
    public double        getTotalRevenue()                  { return bookingDAO.getTotalRevenue(); }
    public int           getTotalBookings()                 { return bookingDAO.getTotalBookings(); }

    public List<Booking> getByDateRange(LocalDate from, LocalDate to) {
        return bookingDAO.findByDateRange(from, to);
    }
}

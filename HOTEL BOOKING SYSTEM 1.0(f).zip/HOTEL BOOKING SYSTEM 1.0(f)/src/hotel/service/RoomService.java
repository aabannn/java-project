package hotel.service;

import hotel.dao.RoomDAO;
import hotel.model.Room;
import hotel.util.ValidationUtil;

import java.time.LocalDate;
import java.util.List;

/**
 * Business logic for room management.
 */
public class RoomService {

    private final RoomDAO roomDAO = new RoomDAO();

    public Room addRoom(String number, Room.RoomType type, double price,
                        int capacity, String amenities, String description) {
        if (!ValidationUtil.isNotBlank(number))  throw new IllegalArgumentException("Room number required.");
        if (!ValidationUtil.isPositive(price))   throw new IllegalArgumentException("Price must be positive.");
        if (capacity < 1)                        throw new IllegalArgumentException("Capacity must be ≥ 1.");

        Room r = new Room(number, type, price, capacity, amenities, description);
        if (!roomDAO.addRoom(r)) throw new RuntimeException("Failed to add room.");
        return r;
    }

    public boolean updateRoom(Room r) {
        if (r == null || r.getRoomId() <= 0) throw new IllegalArgumentException("Invalid room.");
        return roomDAO.update(r);
    }

    public boolean deleteRoom(int roomId) {
        return roomDAO.delete(roomId);
    }

    public List<Room> getAllRooms()                             { return roomDAO.findAll(); }
    public Room       getRoomById(int id)                      { return roomDAO.findById(id); }
    public List<Room> getAvailableRooms(LocalDate in, LocalDate out) {
        return roomDAO.findAvailable(in, out);
    }
    public List<Room> getRoomsByType(String type)              { return roomDAO.findByType(type); }
}

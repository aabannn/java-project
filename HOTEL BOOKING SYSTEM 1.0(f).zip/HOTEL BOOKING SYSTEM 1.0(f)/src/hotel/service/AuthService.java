package hotel.service;

import hotel.dao.CustomerDAO;
import hotel.model.Customer;
import hotel.util.ValidationUtil;

/**
 * Handles registration and login logic.
 */
public class AuthService {

    private final CustomerDAO customerDAO = new CustomerDAO();

    // Logged-in user held in memory for the session
    private static Customer currentUser;

    public Customer login(String username, String password) {
        if (!ValidationUtil.isNotBlank(username) || !ValidationUtil.isNotBlank(password)) {
            throw new IllegalArgumentException("Username and password are required.");
        }
        Customer c = customerDAO.authenticate(username, password);
        if (c == null) throw new SecurityException("Invalid credentials.");
        currentUser = c;
        System.out.println("[Auth] Logged in: " + c.getUsername() + " (" + c.getRole() + ")");
        return c;
    }

    public Customer register(String name, String email, String phone,
                             String address, String username, String password) {
        if (!ValidationUtil.isNotBlank(name))         throw new IllegalArgumentException("Name required.");
        if (!ValidationUtil.isValidEmail(email))       throw new IllegalArgumentException("Invalid email.");
        if (!ValidationUtil.isValidPhone(phone))       throw new IllegalArgumentException("Invalid phone.");
        if (!ValidationUtil.isNotBlank(username))      throw new IllegalArgumentException("Username required.");
        if (!ValidationUtil.isValidPassword(password)) throw new IllegalArgumentException("Password must be ≥ 6 chars.");
        if (customerDAO.usernameExists(username))      throw new IllegalArgumentException("Username already taken.");

        Customer c = new Customer(name, email, phone, address, username, password, "CUSTOMER");
        if (!customerDAO.register(c)) throw new RuntimeException("Registration failed.");
        return c;
    }

    public void logout() {
        System.out.println("[Auth] Logged out: " + (currentUser != null ? currentUser.getUsername() : "-"));
        currentUser = null;
    }

    public static Customer getCurrentUser() { return currentUser; }
    public static boolean isLoggedIn()      { return currentUser != null; }
    public static boolean isAdmin()         { return isLoggedIn() && currentUser.isAdmin(); }
}

package hotel.dao;

import hotel.config.DatabaseConnection;
import hotel.model.Booking;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Data-Access Object for Booking operations.
 */
public class BookingDAO {

    private Connection getConn() {
        return DatabaseConnection.getInstance().getConnection();
    }

    // ── CREATE ────────────────────────────────────────────────────────────────

    public boolean create(Booking b) {
        String sql = "INSERT INTO bookings (customer_id,room_id,check_in_date,check_out_date,"
                   + "total_amount,status,special_requests) VALUES (?,?,?,?,?,?,?)";
        try (PreparedStatement ps = getConn().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, b.getCustomerId());
            ps.setInt(2, b.getRoomId());
            ps.setDate(3, Date.valueOf(b.getCheckInDate()));
            ps.setDate(4, Date.valueOf(b.getCheckOutDate()));
            ps.setDouble(5, b.getTotalAmount());
            ps.setString(6, b.getStatus().name());
            ps.setString(7, b.getSpecialRequests());
            int rows = ps.executeUpdate();
            if (rows > 0) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) b.setBookingId(rs.getInt(1));
                return true;
            }
        } catch (SQLException e) {
            System.err.println("[BookingDAO.create] " + e.getMessage());
        }
        return false;
    }

    // ── READ ──────────────────────────────────────────────────────────────────

    public List<Booking> findAll() {
        return query("SELECT b.*, c.name AS customer_name, r.room_number, r.room_type "
                   + "FROM bookings b "
                   + "JOIN customers c ON b.customer_id = c.customer_id "
                   + "JOIN rooms r ON b.room_id = r.room_id "
                   + "ORDER BY b.created_at DESC", null);
    }

    public List<Booking> findByCustomer(int customerId) {
        return query("SELECT b.*, c.name AS customer_name, r.room_number, r.room_type "
                   + "FROM bookings b "
                   + "JOIN customers c ON b.customer_id = c.customer_id "
                   + "JOIN rooms r ON b.room_id = r.room_id "
                   + "WHERE b.customer_id = ? ORDER BY b.created_at DESC",
                   new Object[]{customerId});
    }

    public Booking findById(int id) {
        List<Booking> list = query(
                "SELECT b.*, c.name AS customer_name, r.room_number, r.room_type "
              + "FROM bookings b "
              + "JOIN customers c ON b.customer_id = c.customer_id "
              + "JOIN rooms r ON b.room_id = r.room_id "
              + "WHERE b.booking_id = ?",
              new Object[]{id});
        return list.isEmpty() ? null : list.get(0);
    }

    public List<Booking> findByDateRange(LocalDate from, LocalDate to) {
        return query("SELECT b.*, c.name AS customer_name, r.room_number, r.room_type "
                   + "FROM bookings b "
                   + "JOIN customers c ON b.customer_id = c.customer_id "
                   + "JOIN rooms r ON b.room_id = r.room_id "
                   + "WHERE b.check_in_date BETWEEN ? AND ? ORDER BY b.check_in_date",
                   new Object[]{Date.valueOf(from), Date.valueOf(to)});
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────

    public boolean updateStatus(int bookingId, Booking.Status status) {
        String sql = "UPDATE bookings SET status = ? WHERE booking_id = ?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setString(1, status.name());
            ps.setInt(2, bookingId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[BookingDAO.updateStatus] " + e.getMessage());
        }
        return false;
    }

    // ── REPORTS ───────────────────────────────────────────────────────────────

    public double getTotalRevenue() {
        String sql = "SELECT COALESCE(SUM(total_amount),0) FROM bookings WHERE status='CONFIRMED'";
        try (Statement st = getConn().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) {
            System.err.println("[BookingDAO.getTotalRevenue] " + e.getMessage());
        }
        return 0;
    }

    public int getTotalBookings() {
        String sql = "SELECT COUNT(*) FROM bookings";
        try (Statement st = getConn().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("[BookingDAO.getTotalBookings] " + e.getMessage());
        }
        return 0;
    }

    // ── HELPERS ───────────────────────────────────────────────────────────────

    private List<Booking> query(String sql, Object[] params) {
        List<Booking> list = new ArrayList<>();
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            if (params != null) {
                for (int i = 0; i < params.length; i++) {
                    ps.setObject(i + 1, params[i]);
                }
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("[BookingDAO.query] " + e.getMessage());
        }
        return list;
    }

    private Booking mapRow(ResultSet rs) throws SQLException {
        Booking b = new Booking();
        b.setBookingId(rs.getInt("booking_id"));
        b.setCustomerId(rs.getInt("customer_id"));
        b.setRoomId(rs.getInt("room_id"));
        b.setCheckInDate(rs.getDate("check_in_date").toLocalDate());
        b.setCheckOutDate(rs.getDate("check_out_date").toLocalDate());
        b.setTotalAmount(rs.getDouble("total_amount"));
        b.setStatus(Booking.Status.valueOf(rs.getString("status")));
        b.setSpecialRequests(rs.getString("special_requests"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) b.setCreatedAt(ts.toLocalDateTime());
        // joined fields
        try { b.setCustomerName(rs.getString("customer_name")); } catch (SQLException ignored) {}
        try { b.setRoomNumber(rs.getString("room_number"));     } catch (SQLException ignored) {}
        try { b.setRoomType(rs.getString("room_type"));         } catch (SQLException ignored) {}
        return b;
    }
}

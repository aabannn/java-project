package hotel.dao;

import hotel.config.DatabaseConnection;
import hotel.model.Room;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Data-Access Object for Room operations.
 */
public class RoomDAO {

    private Connection getConn() {
        return DatabaseConnection.getInstance().getConnection();
    }

    // ── CREATE ────────────────────────────────────────────────────────────────

    public boolean addRoom(Room r) {
        String sql = "INSERT INTO rooms (room_number,room_type,price_per_night,status,capacity,amenities,description) "
                   + "VALUES (?,?,?,?,?,?,?)";
        try (PreparedStatement ps = getConn().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, r.getRoomNumber());
            ps.setString(2, r.getRoomType().name());
            ps.setDouble(3, r.getPricePerNight());
            ps.setString(4, r.getStatus().name());
            ps.setInt(5, r.getCapacity());
            ps.setString(6, r.getAmenities());
            ps.setString(7, r.getDescription());
            int rows = ps.executeUpdate();
            if (rows > 0) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) r.setRoomId(rs.getInt(1));
                return true;
            }
        } catch (SQLException e) {
            System.err.println("[RoomDAO.addRoom] " + e.getMessage());
        }
        return false;
    }

    // ── READ ──────────────────────────────────────────────────────────────────

    public List<Room> findAll() {
        List<Room> list = new ArrayList<>();
        String sql = "SELECT * FROM rooms ORDER BY room_number";
        try (Statement st = getConn().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("[RoomDAO.findAll] " + e.getMessage());
        }
        return list;
    }

    public Room findById(int id) {
        String sql = "SELECT * FROM rooms WHERE room_id = ?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) {
            System.err.println("[RoomDAO.findById] " + e.getMessage());
        }
        return null;
    }

    /** Returns rooms not booked for the requested date range. */
    public List<Room> findAvailable(LocalDate checkIn, LocalDate checkOut) {
        List<Room> list = new ArrayList<>();
        String sql = "SELECT r.* FROM rooms r "
                   + "WHERE r.status = 'AVAILABLE' "
                   + "AND r.room_id NOT IN ("
                   + "  SELECT b.room_id FROM bookings b "
                   + "  WHERE b.status IN ('CONFIRMED','PENDING') "
                   + "  AND NOT (b.check_out_date <= ? OR b.check_in_date >= ?)"
                   + ") ORDER BY r.room_type, r.price_per_night";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(checkIn));
            ps.setDate(2, Date.valueOf(checkOut));
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("[RoomDAO.findAvailable] " + e.getMessage());
        }
        return list;
    }

    public List<Room> findByType(String type) {
        List<Room> list = new ArrayList<>();
        String sql = "SELECT * FROM rooms WHERE room_type = ? ORDER BY price_per_night";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setString(1, type);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("[RoomDAO.findByType] " + e.getMessage());
        }
        return list;
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────

    public boolean update(Room r) {
        String sql = "UPDATE rooms SET room_number=?,room_type=?,price_per_night=?,"
                   + "status=?,capacity=?,amenities=?,description=? WHERE room_id=?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setString(1, r.getRoomNumber());
            ps.setString(2, r.getRoomType().name());
            ps.setDouble(3, r.getPricePerNight());
            ps.setString(4, r.getStatus().name());
            ps.setInt(5, r.getCapacity());
            ps.setString(6, r.getAmenities());
            ps.setString(7, r.getDescription());
            ps.setInt(8, r.getRoomId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[RoomDAO.update] " + e.getMessage());
        }
        return false;
    }

    public boolean updateStatus(int roomId, Room.Status status) {
        String sql = "UPDATE rooms SET status = ? WHERE room_id = ?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setString(1, status.name());
            ps.setInt(2, roomId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[RoomDAO.updateStatus] " + e.getMessage());
        }
        return false;
    }

    // ── DELETE ────────────────────────────────────────────────────────────────

    public boolean delete(int roomId) {
        String sql = "DELETE FROM rooms WHERE room_id = ?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setInt(1, roomId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[RoomDAO.delete] " + e.getMessage());
        }
        return false;
    }

    // ── MAPPING ───────────────────────────────────────────────────────────────

    private Room mapRow(ResultSet rs) throws SQLException {
        Room r = new Room();
        r.setRoomId(rs.getInt("room_id"));
        r.setRoomNumber(rs.getString("room_number"));
        r.setRoomType(Room.RoomType.valueOf(rs.getString("room_type")));
        r.setPricePerNight(rs.getDouble("price_per_night"));
        r.setStatus(Room.Status.valueOf(rs.getString("status")));
        r.setCapacity(rs.getInt("capacity"));
        r.setAmenities(rs.getString("amenities"));
        r.setDescription(rs.getString("description"));
        return r;
    }
}

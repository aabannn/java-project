package hotel.dao;

import hotel.config.DatabaseConnection;
import hotel.model.Customer;
import hotel.util.PasswordUtil;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Data-Access Object for Customer operations.
 */
public class CustomerDAO {

    private Connection getConn() {
        return DatabaseConnection.getInstance().getConnection();
    }

    // ── CREATE ────────────────────────────────────────────────────────────────

    public boolean register(Customer c) {
        String sql = "INSERT INTO customers (name,email,phone,address,username,password,role,active) "
                   + "VALUES (?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = getConn().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, c.getName());
            ps.setString(2, c.getEmail());
            ps.setString(3, c.getPhone());
            ps.setString(4, c.getAddress());
            ps.setString(5, c.getUsername());
            ps.setString(6, PasswordUtil.hash(c.getPassword()));
            ps.setString(7, c.getRole() == null ? "CUSTOMER" : c.getRole());
            ps.setBoolean(8, true);
            int rows = ps.executeUpdate();
            if (rows > 0) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) c.setCustomerId(rs.getInt(1));
                return true;
            }
        } catch (SQLException e) {
            System.err.println("[CustomerDAO.register] " + e.getMessage());
        }
        return false;
    }

    // ── READ ──────────────────────────────────────────────────────────────────

    public Customer findByUsername(String username) {
        String sql = "SELECT * FROM customers WHERE username = ? AND active = 1";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) {
            System.err.println("[CustomerDAO.findByUsername] " + e.getMessage());
        }
        return null;
    }

    public Customer findById(int id) {
        String sql = "SELECT * FROM customers WHERE customer_id = ?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) {
            System.err.println("[CustomerDAO.findById] " + e.getMessage());
        }
        return null;
    }

    public List<Customer> findAll() {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT * FROM customers ORDER BY name";
        try (Statement st = getConn().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("[CustomerDAO.findAll] " + e.getMessage());
        }
        return list;
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────

    public boolean update(Customer c) {
        String sql = "UPDATE customers SET name=?,email=?,phone=?,address=? WHERE customer_id=?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setString(1, c.getName());
            ps.setString(2, c.getEmail());
            ps.setString(3, c.getPhone());
            ps.setString(4, c.getAddress());
            ps.setInt(5, c.getCustomerId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CustomerDAO.update] " + e.getMessage());
        }
        return false;
    }

    public boolean deactivate(int id) {
        String sql = "UPDATE customers SET active = 0 WHERE customer_id = ?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CustomerDAO.deactivate] " + e.getMessage());
        }
        return false;
    }

    // ── AUTH ──────────────────────────────────────────────────────────────────

    public Customer authenticate(String username, String rawPassword) {
        Customer c = findByUsername(username);
        if (c != null && PasswordUtil.verify(rawPassword, c.getPassword())) return c;
        return null;
    }

    public boolean usernameExists(String username) {
        String sql = "SELECT 1 FROM customers WHERE username = ?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setString(1, username);
            return ps.executeQuery().next();
        } catch (SQLException e) {
            System.err.println("[CustomerDAO.usernameExists] " + e.getMessage());
        }
        return false;
    }

    // ── MAPPING ───────────────────────────────────────────────────────────────

    private Customer mapRow(ResultSet rs) throws SQLException {
        Customer c = new Customer();
        c.setCustomerId(rs.getInt("customer_id"));
        c.setName(rs.getString("name"));
        c.setEmail(rs.getString("email"));
        c.setPhone(rs.getString("phone"));
        c.setAddress(rs.getString("address"));
        c.setUsername(rs.getString("username"));
        c.setPassword(rs.getString("password"));
        c.setRole(rs.getString("role"));
        c.setActive(rs.getBoolean("active"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) c.setCreatedAt(ts.toLocalDateTime());
        return c;
    }
    public void updateCustomer(int id, String name, String email, String phone) {
        String sql = "UPDATE customers SET name=?, email=?, phone=? WHERE customer_id=?";
        try (java.sql.Connection con = hotel.config.DatabaseConnection.getConnection();
             java.sql.PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, phone);
            ps.setInt(4, id);
            ps.executeUpdate();
        } catch (Exception e) {
            throw new RuntimeException("Failed to update customer: " + e.getMessage());
        }
    }
    
    public void deleteCustomer(int id) {
        String sql = "DELETE FROM customers WHERE customer_id=?";
        try (java.sql.Connection con = hotel.config.DatabaseConnection.getConnection();
             java.sql.PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            throw new RuntimeException("Failed to delete customer: " + e.getMessage());
        }
    }
    
    public void toggleActive(int id, boolean active) {
        String sql = "UPDATE customers SET active=? WHERE customer_id=?";
        try (java.sql.Connection con = hotel.config.DatabaseConnection.getConnection();
             java.sql.PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBoolean(1, active);
            ps.setInt(2, id);
            ps.executeUpdate();
        } catch (Exception e) {
            throw new RuntimeException("Failed to update status: " + e.getMessage());
        }
    }
}

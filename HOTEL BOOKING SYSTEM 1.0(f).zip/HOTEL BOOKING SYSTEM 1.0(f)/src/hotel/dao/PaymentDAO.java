package hotel.dao;

import hotel.config.DatabaseConnection;
import hotel.model.Payment;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data-Access Object for Payment operations.
 */
public class PaymentDAO {

    private Connection getConn() {
        return DatabaseConnection.getInstance().getConnection();
    }

    public boolean create(Payment p) {
        String sql = "INSERT INTO payments (booking_id,amount,tax_amount,total_amount,"
                   + "payment_method,payment_status,transaction_ref) VALUES (?,?,?,?,?,?,?)";
        try (PreparedStatement ps = getConn().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, p.getBookingId());
            ps.setDouble(2, p.getAmount());
            ps.setDouble(3, p.getTaxAmount());
            ps.setDouble(4, p.getTotalAmount());
            ps.setString(5, p.getPaymentMethod().name());
            ps.setString(6, p.getPaymentStatus().name());
            ps.setString(7, p.getTransactionRef());
            int rows = ps.executeUpdate();
            if (rows > 0) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) p.setPaymentId(rs.getInt(1));
                return true;
            }
        } catch (SQLException e) {
            System.err.println("[PaymentDAO.create] " + e.getMessage());
        }
        return false;
    }

    public List<Payment> findAll() {
        List<Payment> list = new ArrayList<>();
        String sql = "SELECT p.*, c.name AS customer_name "
                   + "FROM payments p "
                   + "JOIN bookings b ON p.booking_id = b.booking_id "
                   + "JOIN customers c ON b.customer_id = c.customer_id "
                   + "ORDER BY p.payment_date DESC";
        try (Statement st = getConn().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("[PaymentDAO.findAll] " + e.getMessage());
        }
        return list;
    }

    public Payment findByBookingId(int bookingId) {
        String sql = "SELECT p.*, c.name AS customer_name "
                   + "FROM payments p "
                   + "JOIN bookings b ON p.booking_id = b.booking_id "
                   + "JOIN customers c ON b.customer_id = c.customer_id "
                   + "WHERE p.booking_id = ?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setInt(1, bookingId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) {
            System.err.println("[PaymentDAO.findByBookingId] " + e.getMessage());
        }
        return null;
    }

    public double getTotalRevenue() {
        String sql = "SELECT COALESCE(SUM(total_amount),0) FROM payments WHERE payment_status='COMPLETED'";
        try (Statement st = getConn().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) {
            System.err.println("[PaymentDAO.getTotalRevenue] " + e.getMessage());
        }
        return 0;
    }

    private Payment mapRow(ResultSet rs) throws SQLException {
        Payment p = new Payment();
        p.setPaymentId(rs.getInt("payment_id"));
        p.setBookingId(rs.getInt("booking_id"));
        p.setAmount(rs.getDouble("amount"));
        p.setTaxAmount(rs.getDouble("tax_amount"));
        p.setTotalAmount(rs.getDouble("total_amount"));
        p.setPaymentMethod(Payment.Method.valueOf(rs.getString("payment_method")));
        p.setPaymentStatus(Payment.Status.valueOf(rs.getString("payment_status")));
        Timestamp ts = rs.getTimestamp("payment_date");
        if (ts != null) p.setPaymentDate(ts.toLocalDateTime());
        p.setTransactionRef(rs.getString("transaction_ref"));
        try { p.setCustomerName(rs.getString("customer_name")); } catch (SQLException ignored) {}
        return p;
    }
}
